"""
PC Bridge GUI

tkinter 기반의 간단한 GUI입니다.
시스템 트레이 아이콘과 상태 표시를 제공합니다.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import threading
import logging
import webbrowser

from config import VERSION, SERVER_PORT
from hana_api import get_hana_api
from server import run_server

logger = logging.getLogger(__name__)


class BridgeGUI:
    """PC Bridge GUI"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"달러인베스트 PC Bridge v{VERSION}")
        self.root.geometry("400x350")
        self.root.resizable(False, False)

        # 아이콘 설정 (있으면)
        try:
            self.root.iconbitmap("icon.ico")
        except:
            pass

        # 서버 스레드
        self.server_thread = None
        self.server_running = False

        # API 인스턴스
        self.api = get_hana_api()

        # UI 생성
        self._create_ui()

        # 종료 시 정리
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _create_ui(self):
        """UI 생성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 타이틀
        title_label = ttk.Label(
            main_frame,
            text="달러인베스트 PC Bridge",
            font=("맑은 고딕", 16, "bold")
        )
        title_label.pack(pady=(0, 5))

        version_label = ttk.Label(
            main_frame,
            text=f"버전 {VERSION}",
            font=("맑은 고딕", 9),
            foreground="gray"
        )
        version_label.pack(pady=(0, 20))

        # 상태 프레임
        status_frame = ttk.LabelFrame(main_frame, text="상태", padding="10")
        status_frame.pack(fill=tk.X, pady=(0, 15))

        # 서버 상태
        server_row = ttk.Frame(status_frame)
        server_row.pack(fill=tk.X, pady=2)
        ttk.Label(server_row, text="브릿지 서버:").pack(side=tk.LEFT)
        self.server_status = ttk.Label(server_row, text="중지됨", foreground="red")
        self.server_status.pack(side=tk.RIGHT)

        # API 연결 상태
        api_row = ttk.Frame(status_frame)
        api_row.pack(fill=tk.X, pady=2)
        ttk.Label(api_row, text="하나증권 API:").pack(side=tk.LEFT)
        self.api_status = ttk.Label(api_row, text="연결 안됨", foreground="red")
        self.api_status.pack(side=tk.RIGHT)

        # 로그인 상태
        login_row = ttk.Frame(status_frame)
        login_row.pack(fill=tk.X, pady=2)
        ttk.Label(login_row, text="로그인:").pack(side=tk.LEFT)
        self.login_status = ttk.Label(login_row, text="로그아웃", foreground="red")
        self.login_status.pack(side=tk.RIGHT)

        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 15))

        # 서버 시작/중지 버튼
        self.server_btn = ttk.Button(
            button_frame,
            text="서버 시작",
            command=self._toggle_server,
            width=15
        )
        self.server_btn.pack(side=tk.LEFT, padx=(0, 10))

        # 로그인 버튼
        self.login_btn = ttk.Button(
            button_frame,
            text="하나증권 로그인",
            command=self._do_login,
            width=15,
            state=tk.DISABLED
        )
        self.login_btn.pack(side=tk.LEFT)

        # 웹 열기 버튼
        web_btn = ttk.Button(
            main_frame,
            text="웹사이트 열기 (localhost:3000)",
            command=lambda: webbrowser.open("http://localhost:3000/broker")
        )
        web_btn.pack(fill=tk.X, pady=(0, 15))

        # 로그 영역
        log_frame = ttk.LabelFrame(main_frame, text="로그", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.log_text = tk.Text(log_frame, height=6, state=tk.DISABLED, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # 초기 로그
        self._log("PC Bridge가 시작되었습니다.")
        self._log("'서버 시작' 버튼을 클릭하세요.")

    def _log(self, message: str):
        """로그 추가"""
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def _update_status(self):
        """상태 업데이트"""
        # 서버 상태
        if self.server_running:
            self.server_status.configure(text=f"실행 중 (:{SERVER_PORT})", foreground="green")
            self.server_btn.configure(text="서버 중지")
            self.login_btn.configure(state=tk.NORMAL)
        else:
            self.server_status.configure(text="중지됨", foreground="red")
            self.server_btn.configure(text="서버 시작")
            self.login_btn.configure(state=tk.DISABLED)

        # API 상태
        if self.api.is_connected:
            self.api_status.configure(text="연결됨", foreground="green")
        else:
            self.api_status.configure(text="연결 안됨", foreground="red")

        # 로그인 상태
        if self.api.is_logged_in:
            self.login_status.configure(text="로그인됨", foreground="green")
            self.login_btn.configure(text="로그아웃")
        else:
            self.login_status.configure(text="로그아웃", foreground="red")
            self.login_btn.configure(text="하나증권 로그인")

    def _toggle_server(self):
        """서버 시작/중지"""
        if self.server_running:
            self._stop_server()
        else:
            self._start_server()

    def _start_server(self):
        """서버 시작"""
        if self.server_running:
            return

        def run():
            try:
                run_server()
            except Exception as e:
                logger.error(f"서버 오류: {e}")
                self.server_running = False
                self.root.after(0, lambda: self._log(f"서버 오류: {e}"))
                self.root.after(0, self._update_status)

        self.server_thread = threading.Thread(target=run, daemon=True)
        self.server_thread.start()
        self.server_running = True

        self._log(f"서버가 시작되었습니다. (포트: {SERVER_PORT})")
        self._update_status()

    def _stop_server(self):
        """서버 중지"""
        # Flask 서버는 graceful shutdown이 어려움
        # 실제로는 프로세스 종료로 처리
        self.server_running = False
        self._log("서버가 중지되었습니다.")
        self._update_status()

    def _do_login(self):
        """하나증권 로그인"""
        if self.api.is_logged_in:
            # 로그아웃
            self.api.logout()
            self._log("로그아웃되었습니다.")
            self._update_status()
            return

        # API 연결 확인
        if not self.api.is_connected:
            self._log("API 연결 중...")
            if not self.api.connect():
                self._log("API 연결 실패!")
                messagebox.showerror("오류", "하나증권 API 연결에 실패했습니다.\n1Q Open API가 설치되어 있는지 확인하세요.")
                return
            self._log("API 연결 성공")
            self._update_status()

        # 로그인 (별도 스레드에서)
        def do_login():
            self._log("로그인 중... (인증서 선택 창 확인)")
            self.login_btn.configure(state=tk.DISABLED)

            if self.api.login():
                self.root.after(0, lambda: self._log("로그인 성공!"))
            else:
                self.root.after(0, lambda: self._log("로그인 실패"))
                self.root.after(0, lambda: messagebox.showerror("오류", "로그인에 실패했습니다."))

            self.root.after(0, self._update_status)
            self.root.after(0, lambda: self.login_btn.configure(state=tk.NORMAL))

        threading.Thread(target=do_login, daemon=True).start()

    def _on_close(self):
        """종료 처리"""
        if self.api.is_logged_in:
            self.api.logout()
        if self.api.is_connected:
            self.api.disconnect()
        self.root.destroy()

    def run(self):
        """GUI 실행"""
        self.root.mainloop()


def main():
    """메인 함수"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )

    gui = BridgeGUI()
    gui.run()


if __name__ == "__main__":
    main()
