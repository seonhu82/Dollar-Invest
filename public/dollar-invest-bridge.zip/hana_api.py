"""
하나증권 1Q Open API 래퍼

하나증권 1Q Open API는 COM/OCX 기반으로 동작합니다.
HFCommAgent 컨트롤을 사용하여 통신합니다.

주요 TR 코드 (실제 코드는 하나증권 API 문서 참조):
- 해외주식 잔고조회: o91600
- 해외주식 체결내역: o91700
- 해외주식 미체결내역: o91702
- 해외주식 매수주문: o91001
- 해외주식 매도주문: o91002
- 해외주식 주문정정: o91003
- 해외주식 주문취소: o91004
- 외화예수금 조회: f40028 또는 o40001

참고:
- 하나증권 API는 32비트 Python에서만 동작
- COM 등록 필요: regsvr32 HFCommAgent.dll
- API 신청: 1QHTS > 화면번호 0789
"""

import win32com.client
import pythoncom
import threading
import time
import logging
from typing import Optional, Callable
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class OrderType(Enum):
    BUY = "2"   # 매수
    SELL = "1"  # 매도


@dataclass
class Balance:
    """잔고 정보"""
    currency: str
    balance: float
    available_balance: float
    avg_buy_rate: float
    profit_loss: float
    profit_loss_percent: float


@dataclass
class Order:
    """주문 정보"""
    order_id: str
    order_type: str
    currency: str
    amount: float
    rate: float
    status: str
    ordered_at: str


class HanaAPIEventHandler:
    """하나증권 API 이벤트 핸들러"""

    def __init__(self, api: 'HanaAPI'):
        self.api = api

    def OnGetData(self, szTRCode: str):
        """데이터 수신 이벤트"""
        logger.info(f"데이터 수신: {szTRCode}")
        if self.api.on_data_callback:
            self.api.on_data_callback(szTRCode)

    def OnGetMsg(self, szCode: str, szMsg: str):
        """메시지 수신 이벤트"""
        logger.info(f"메시지: [{szCode}] {szMsg}")
        if self.api.on_message_callback:
            self.api.on_message_callback(szCode, szMsg)

    def OnGetReal(self, szTRCode: str):
        """실시간 데이터 수신 이벤트"""
        logger.debug(f"실시간: {szTRCode}")

    def OnAgentEventHandler(self, nEventID: int):
        """에이전트 이벤트"""
        logger.info(f"에이전트 이벤트: {nEventID}")
        # 1: 로그인 성공, 2: 로그인 실패, 3: 접속 종료
        if nEventID == 1:
            self.api._login_result = True
            self.api._login_event.set()
        elif nEventID == 2:
            self.api._login_result = False
            self.api._login_event.set()
        elif nEventID == 3:
            self.api._is_connected = False


class HanaAPI:
    """하나증권 1Q Open API 클라이언트"""

    def __init__(self):
        self.agent = None
        self._is_connected = False
        self._is_logged_in = False
        self._login_event = threading.Event()
        self._login_result = False
        self._data_event = threading.Event()
        self._last_data = None

        # 콜백
        self.on_data_callback: Optional[Callable] = None
        self.on_message_callback: Optional[Callable] = None

        # COM 초기화
        self._com_initialized = False

    def _init_com(self):
        """COM 초기화 (스레드별로 필요)"""
        if not self._com_initialized:
            pythoncom.CoInitialize()
            self._com_initialized = True

    def _uninit_com(self):
        """COM 해제"""
        if self._com_initialized:
            pythoncom.CoUninitialize()
            self._com_initialized = False

    def connect(self) -> bool:
        """
        하나증권 API 연결

        Returns:
            연결 성공 여부
        """
        try:
            self._init_com()

            # COM 객체 생성
            self.agent = win32com.client.DispatchWithEvents(
                "HFCommAgent.HFCommAgent.1",
                HanaAPIEventHandler
            )
            # 이벤트 핸들러에 API 참조 전달
            # Note: DispatchWithEvents는 이벤트 클래스의 인스턴스를 내부에서 생성

            # 대안: 직접 Dispatch 사용
            self.agent = win32com.client.Dispatch("HFCommAgent.HFCommAgent.1")

            self._is_connected = True
            logger.info("하나증권 API 연결 성공")
            return True

        except Exception as e:
            logger.error(f"하나증권 API 연결 실패: {e}")
            self._is_connected = False
            return False

    def disconnect(self):
        """API 연결 해제"""
        if self.agent:
            try:
                self.agent.CommTerminate(0)
            except:
                pass
            self.agent = None

        self._is_connected = False
        self._is_logged_in = False
        self._uninit_com()
        logger.info("하나증권 API 연결 해제")

    def login(self, user_id: str = "", password: str = "", cert_password: str = "") -> bool:
        """
        로그인 (공동인증서)

        실제로는 CommLogin 호출 시 인증서 선택 창이 뜹니다.
        user_id, password는 모의투자용입니다.

        Returns:
            로그인 성공 여부
        """
        if not self._is_connected:
            logger.error("API가 연결되지 않았습니다")
            return False

        try:
            self._login_event.clear()

            # 로그인 요청
            # CommLogin(sUserID, sPwd, sCertPwd)
            # 실제 인증서 로그인은 빈 문자열로 호출하면 인증서 선택 창이 뜸
            result = self.agent.CommLogin(user_id, password, cert_password)

            if result < 0:
                logger.error(f"로그인 요청 실패: {result}")
                return False

            # 로그인 결과 대기 (최대 60초)
            if self._login_event.wait(timeout=60):
                if self._login_result:
                    self._is_logged_in = True
                    logger.info("로그인 성공")
                    return True
                else:
                    logger.error("로그인 실패")
                    return False
            else:
                logger.error("로그인 타임아웃")
                return False

        except Exception as e:
            logger.error(f"로그인 오류: {e}")
            return False

    def logout(self):
        """로그아웃"""
        if self.agent and self._is_logged_in:
            try:
                self.agent.CommLogout()
            except:
                pass
            self._is_logged_in = False
            logger.info("로그아웃 완료")

    def get_balance(self, account_no: str) -> Optional[Balance]:
        """
        외화 잔고 조회

        Args:
            account_no: 계좌번호 (예: "123-12-123456")

        Returns:
            Balance 객체 또는 None

        TR 코드: o91600 (해외주식잔고) 또는 f40028 (외화예수금)
        - 계좌번호: 10자리 (하이픈 제외)
        - 계좌상품코드: 01 (위탁), 02 (파생) 등
        - 통화코드: USD, JPY, CNY 등
        """
        if not self._is_logged_in:
            logger.error("로그인이 필요합니다")
            return None

        try:
            # 외화예수금 조회 TR
            tr_code = "f40028"

            account_no_clean = account_no.replace("-", "")

            # 입력값 설정 (실제 필드명은 API 문서 참조)
            self.agent.SetFieldData(tr_code, "계좌번호", 0, account_no_clean[:8])
            self.agent.SetFieldData(tr_code, "계좌상품코드", 0, account_no_clean[8:10] if len(account_no_clean) > 8 else "01")
            self.agent.SetFieldData(tr_code, "통화코드", 0, "USD")

            # 조회 요청
            self._data_event.clear()
            result = self.agent.CommRqData(tr_code, tr_code, 0, "")

            if result < 0:
                logger.error(f"잔고 조회 요청 실패: {result}")
                return None

            # 응답 대기
            if not self._data_event.wait(timeout=10):
                logger.error("잔고 조회 타임아웃")
                return None

            # 결과 파싱 (필드명은 실제 API 응답에 맞게 수정 필요)
            balance = float(self.agent.GetFieldData(tr_code, "외화예수금", 0) or 0)
            available = float(self.agent.GetFieldData(tr_code, "출금가능금액", 0) or 0)
            avg_rate = float(self.agent.GetFieldData(tr_code, "평균매입환율", 0) or 0)
            profit = float(self.agent.GetFieldData(tr_code, "평가손익", 0) or 0)

            return Balance(
                currency="USD",
                balance=balance,
                available_balance=available,
                avg_buy_rate=avg_rate,
                profit_loss=profit,
                profit_loss_percent=(profit / (balance * avg_rate) * 100) if balance > 0 and avg_rate > 0 else 0
            )

        except Exception as e:
            logger.error(f"잔고 조회 오류: {e}")
            return None

    def place_order(
        self,
        account_no: str,
        order_type: OrderType,
        amount: float,
        rate: float = 0,  # 0이면 시장가
        password: str = ""
    ) -> Optional[str]:
        """
        외화 주문 (해외주식 매수/매도)

        Args:
            account_no: 계좌번호
            order_type: 주문유형 (BUY/SELL)
            amount: 주문금액 (USD)
            rate: 주문환율 (0이면 시장가)
            password: 계좌비밀번호

        Returns:
            주문번호 또는 None

        TR 코드:
        - 매수: o91001
        - 매도: o91002
        """
        if not self._is_logged_in:
            logger.error("로그인이 필요합니다")
            return None

        try:
            # TR 코드 설정
            tr_code = "o91001" if order_type == OrderType.BUY else "o91002"

            account_no_clean = account_no.replace("-", "")

            # 입력값 설정 (필드명은 API 문서 참조)
            self.agent.SetFieldData(tr_code, "계좌번호", 0, account_no_clean[:8])
            self.agent.SetFieldData(tr_code, "계좌상품코드", 0, account_no_clean[8:10] if len(account_no_clean) > 8 else "01")
            self.agent.SetFieldData(tr_code, "계좌비밀번호", 0, password)
            self.agent.SetFieldData(tr_code, "매매구분", 0, order_type.value)
            self.agent.SetFieldData(tr_code, "통화코드", 0, "USD")
            self.agent.SetFieldData(tr_code, "주문금액", 0, str(amount))
            self.agent.SetFieldData(tr_code, "주문단가", 0, str(rate) if rate > 0 else "0")
            self.agent.SetFieldData(tr_code, "주문유형", 0, "00" if rate == 0 else "01")  # 시장가/지정가

            # 주문 요청
            self._data_event.clear()
            result = self.agent.CommRqData(tr_code, tr_code, 0, "")

            if result < 0:
                logger.error(f"주문 요청 실패: {result}")
                return None

            # 응답 대기
            if not self._data_event.wait(timeout=10):
                logger.error("주문 타임아웃")
                return None

            # 주문번호 반환
            order_id = self.agent.GetFieldData(tr_code, "주문번호", 0)
            logger.info(f"주문 완료: {order_id}")
            return order_id

        except Exception as e:
            logger.error(f"주문 오류: {e}")
            return None

    def get_orders(self, account_no: str, start_date: str = "", end_date: str = "") -> list[Order]:
        """
        주문 내역 (체결내역) 조회

        Args:
            account_no: 계좌번호
            start_date: 시작일 (YYYYMMDD)
            end_date: 종료일 (YYYYMMDD)

        Returns:
            Order 목록

        TR 코드: o91700 (해외주식 체결내역)
        """
        if not self._is_logged_in:
            logger.error("로그인이 필요합니다")
            return []

        try:
            tr_code = "o91700"

            # 날짜 기본값
            if not end_date:
                end_date = time.strftime("%Y%m%d")
            if not start_date:
                start_date = time.strftime("%Y%m%d", time.localtime(time.time() - 30*24*60*60))

            account_no_clean = account_no.replace("-", "")

            # 입력값 설정
            self.agent.SetFieldData(tr_code, "계좌번호", 0, account_no_clean[:8])
            self.agent.SetFieldData(tr_code, "계좌상품코드", 0, account_no_clean[8:10] if len(account_no_clean) > 8 else "01")
            self.agent.SetFieldData(tr_code, "조회시작일", 0, start_date)
            self.agent.SetFieldData(tr_code, "조회종료일", 0, end_date)
            self.agent.SetFieldData(tr_code, "통화코드", 0, "USD")

            # 조회 요청
            self._data_event.clear()
            result = self.agent.CommRqData(tr_code, tr_code, 0, "")

            if result < 0:
                logger.error(f"거래내역 조회 요청 실패: {result}")
                return []

            # 응답 대기
            if not self._data_event.wait(timeout=10):
                logger.error("거래내역 조회 타임아웃")
                return []

            # 결과 파싱
            orders = []
            count = self.agent.GetRepeatCnt(tr_code, "")

            for i in range(count):
                order_id = self.agent.GetFieldData(tr_code, "주문번호", i) or ""
                trade_type = self.agent.GetFieldData(tr_code, "매매구분", i) or ""
                amount = float(self.agent.GetFieldData(tr_code, "체결금액", i) or 0)
                rate = float(self.agent.GetFieldData(tr_code, "체결단가", i) or 0)
                trade_date = self.agent.GetFieldData(tr_code, "체결일자", i) or ""
                trade_time = self.agent.GetFieldData(tr_code, "체결시간", i) or ""

                order = Order(
                    order_id=order_id,
                    order_type="BUY" if trade_type == "2" or trade_type == "매수" else "SELL",
                    currency="USD",
                    amount=amount,
                    rate=rate,
                    status="COMPLETED",
                    ordered_at=f"{trade_date} {trade_time}".strip()
                )
                orders.append(order)

            return orders

        except Exception as e:
            logger.error(f"거래내역 조회 오류: {e}")
            return []

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    @property
    def is_logged_in(self) -> bool:
        return self._is_logged_in


# 싱글톤 인스턴스
_api_instance: Optional[HanaAPI] = None


def get_hana_api() -> HanaAPI:
    """하나증권 API 싱글톤 인스턴스 반환"""
    global _api_instance
    if _api_instance is None:
        _api_instance = HanaAPI()
    return _api_instance
