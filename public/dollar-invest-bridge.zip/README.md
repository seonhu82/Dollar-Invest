# 달러인베스트 PC Bridge

하나증권 1Q Open API와 달러인베스트 웹 앱을 연결하는 브릿지 프로그램입니다.

## 시스템 요구사항

- Windows 10 이상
- Python 3.10 이상
- 하나증권 1Q Open API 설치
- 공동인증서 (금융인증서는 미지원)

## 설치 방법

### 1. 하나증권 1Q Open API 설치

1. [하나증권 홈페이지](https://www.hanaw.com)에서 1Q Open API 신청
2. API 프로그램 다운로드 및 설치
3. COM 컴포넌트 등록 확인

### 2. Python 의존성 설치

```bash
cd dollar-invest-bridge
pip install -r requirements.txt
```

## 실행 방법

### GUI 모드 (권장)

```bash
python main.py
```

1. 프로그램 실행
2. "서버 시작" 버튼 클릭
3. "하나증권 로그인" 버튼 클릭
4. 공동인증서 선택 및 비밀번호 입력
5. 웹 브라우저에서 http://localhost:3000/broker 접속

### 서버 모드 (헤드리스)

```bash
python main.py --server
```

옵션:
- `--port 8585`: 서버 포트 지정
- `--debug`: 디버그 모드

## API 엔드포인트

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /api/status | 브릿지 상태 조회 |
| GET | /api/health | 헬스 체크 |
| POST | /api/hana/connect | API 연결 |
| POST | /api/hana/disconnect | API 연결 해제 |
| POST | /api/hana/login | 로그인 |
| POST | /api/hana/logout | 로그아웃 |
| POST | /api/hana/balance | 잔고 조회 |
| POST | /api/hana/order/buy | 매수 주문 |
| POST | /api/hana/order/sell | 매도 주문 |
| POST | /api/hana/orders | 거래내역 조회 |

## 문제 해결

### "하나증권 API 연결 실패" 오류

1. 1Q Open API가 설치되어 있는지 확인
2. COM 컴포넌트가 등록되어 있는지 확인:
   ```bash
   # 관리자 권한으로 실행
   regsvr32 "C:\하나증권\1Q Open API\HFCommAgent.ocx"
   ```

### "로그인 실패" 오류

1. 공동인증서가 유효한지 확인
2. 인증서 비밀번호 확인
3. 하나증권 계좌가 API 사용 신청되어 있는지 확인

### 서버 연결 안됨

1. 방화벽에서 8585 포트가 열려 있는지 확인
2. 다른 프로그램이 8585 포트를 사용하고 있지 않은지 확인

## 보안 주의사항

- 이 프로그램은 localhost에서만 접근 가능합니다
- 계좌 비밀번호는 저장되지 않습니다
- 인증서 비밀번호는 로그인 시에만 사용됩니다

## TR 코드 참고

현재 구현된 TR 코드는 예상 값이며, 실제 사용 전 하나증권 API 문서에서 확인이 필요합니다:

| 기능 | 예상 TR 코드 | 설명 |
|------|-------------|------|
| 외화예수금 조회 | f40028 | 외화 잔고 조회 |
| 해외주식 잔고 | o91600 | 해외주식 보유 잔고 |
| 해외주식 체결 | o91700 | 체결 내역 조회 |
| 해외주식 매수 | o91001 | 매수 주문 |
| 해외주식 매도 | o91002 | 매도 주문 |

**TR 코드 확인 방법:**
1. 1QHTS 실행 → API 신청 후 설치
2. API 매뉴얼/가이드 문서 확인
3. 하나증권 고객센터 문의: 02-3771-3771

## 라이선스

MIT License
