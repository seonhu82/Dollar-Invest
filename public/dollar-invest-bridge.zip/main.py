"""
달러인베스트 PC Bridge

하나증권 1Q Open API와 웹 앱을 연결하는 브릿지 프로그램입니다.

사용법:
    python main.py          # GUI 모드로 실행
    python main.py --server # 서버 모드로 실행 (GUI 없음)
"""

import sys
import argparse
import logging

from config import VERSION, LOG_FILE, LOG_LEVEL


def setup_logging(level: str = LOG_LEVEL):
    """로깅 설정"""
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(LOG_FILE, encoding="utf-8"),
        ]
    )


def main():
    """메인 함수"""
    parser = argparse.ArgumentParser(
        description=f"달러인베스트 PC Bridge v{VERSION}"
    )
    parser.add_argument(
        "--server",
        action="store_true",
        help="서버 모드로 실행 (GUI 없음)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="서버 포트 (기본: 8585)"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="디버그 모드"
    )

    args = parser.parse_args()

    # 로깅 설정
    setup_logging("DEBUG" if args.debug else LOG_LEVEL)
    logger = logging.getLogger(__name__)

    logger.info(f"달러인베스트 PC Bridge v{VERSION}")

    if args.server:
        # 서버 모드
        logger.info("서버 모드로 시작합니다.")
        from server import run_server
        run_server(port=args.port)
    else:
        # GUI 모드
        logger.info("GUI 모드로 시작합니다.")
        from gui import main as gui_main
        gui_main()


if __name__ == "__main__":
    main()
