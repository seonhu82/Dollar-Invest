"""
PC Bridge HTTP 서버

웹 앱과 하나증권 API 사이의 브릿지 역할을 하는 HTTP 서버입니다.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
from functools import wraps

from config import SERVER_HOST, SERVER_PORT, VERSION
from hana_api import get_hana_api, OrderType

logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000", "http://127.0.0.1:3000"])


def api_response(success: bool, data: dict = None, error: str = None, status: int = 200):
    """API 응답 헬퍼"""
    response = {"success": success}
    if data:
        response.update(data)
    if error:
        response["error"] = error
    return jsonify(response), status


def require_login(f):
    """로그인 필수 데코레이터"""
    @wraps(f)
    def decorated(*args, **kwargs):
        api = get_hana_api()
        if not api.is_logged_in:
            return api_response(False, error="로그인이 필요합니다.", status=401)
        return f(*args, **kwargs)
    return decorated


# ==================== 상태 API ====================

@app.route("/api/status", methods=["GET"])
def get_status():
    """브릿지 상태 조회"""
    api = get_hana_api()
    return api_response(True, {
        "version": VERSION,
        "connected": api.is_connected,
        "hanaConnected": api.is_logged_in,
    })


@app.route("/api/health", methods=["GET"])
def health_check():
    """헬스 체크"""
    return api_response(True, {"status": "ok", "version": VERSION})


# ==================== 연결 API ====================

@app.route("/api/hana/connect", methods=["POST"])
def hana_connect():
    """하나증권 API 연결"""
    api = get_hana_api()

    if api.is_connected:
        return api_response(True, {"message": "이미 연결되어 있습니다."})

    if api.connect():
        return api_response(True, {"message": "연결 성공"})
    else:
        return api_response(False, error="연결 실패", status=500)


@app.route("/api/hana/disconnect", methods=["POST"])
def hana_disconnect():
    """하나증권 API 연결 해제"""
    api = get_hana_api()
    api.disconnect()
    return api_response(True, {"message": "연결 해제 완료"})


@app.route("/api/hana/login", methods=["POST"])
def hana_login():
    """하나증권 로그인"""
    api = get_hana_api()

    if not api.is_connected:
        # 자동 연결 시도
        if not api.connect():
            return api_response(False, error="API 연결 실패", status=500)

    if api.is_logged_in:
        return api_response(True, {"message": "이미 로그인되어 있습니다."})

    # 로그인 (인증서 선택 창이 뜸)
    data = request.get_json() or {}
    user_id = data.get("userId", "")
    password = data.get("password", "")
    cert_password = data.get("certPassword", "")

    if api.login(user_id, password, cert_password):
        return api_response(True, {"message": "로그인 성공"})
    else:
        return api_response(False, error="로그인 실패", status=401)


@app.route("/api/hana/logout", methods=["POST"])
def hana_logout():
    """하나증권 로그아웃"""
    api = get_hana_api()
    api.logout()
    return api_response(True, {"message": "로그아웃 완료"})


# ==================== 잔고 API ====================

@app.route("/api/hana/balance", methods=["POST"])
@require_login
def get_balance():
    """외화 잔고 조회"""
    api = get_hana_api()
    data = request.get_json() or {}
    account_no = data.get("accountNo", "")

    if not account_no:
        return api_response(False, error="계좌번호가 필요합니다.", status=400)

    balance = api.get_balance(account_no)

    if balance:
        return api_response(True, {
            "balance": {
                "currency": balance.currency,
                "balance": balance.balance,
                "availableBalance": balance.available_balance,
                "avgBuyRate": balance.avg_buy_rate,
                "profitLoss": balance.profit_loss,
                "profitLossPercent": balance.profit_loss_percent,
            }
        })
    else:
        return api_response(False, error="잔고 조회 실패", status=500)


# ==================== 주문 API ====================

@app.route("/api/hana/order/buy", methods=["POST"])
@require_login
def place_buy_order():
    """외화 매수 주문"""
    api = get_hana_api()
    data = request.get_json() or {}

    account_no = data.get("accountNo", "")
    amount = float(data.get("amount", 0))
    rate = float(data.get("rate", 0))
    password = data.get("password", "")

    if not account_no or amount <= 0:
        return api_response(False, error="필수 정보가 누락되었습니다.", status=400)

    order_id = api.place_order(account_no, OrderType.BUY, amount, rate, password)

    if order_id:
        return api_response(True, {
            "orderId": order_id,
            "message": "매수 주문이 접수되었습니다."
        })
    else:
        return api_response(False, error="주문 실패", status=500)


@app.route("/api/hana/order/sell", methods=["POST"])
@require_login
def place_sell_order():
    """외화 매도 주문"""
    api = get_hana_api()
    data = request.get_json() or {}

    account_no = data.get("accountNo", "")
    amount = float(data.get("amount", 0))
    rate = float(data.get("rate", 0))
    password = data.get("password", "")

    if not account_no or amount <= 0:
        return api_response(False, error="필수 정보가 누락되었습니다.", status=400)

    order_id = api.place_order(account_no, OrderType.SELL, amount, rate, password)

    if order_id:
        return api_response(True, {
            "orderId": order_id,
            "message": "매도 주문이 접수되었습니다."
        })
    else:
        return api_response(False, error="주문 실패", status=500)


# ==================== 거래내역 API ====================

@app.route("/api/hana/orders", methods=["POST"])
@require_login
def get_orders():
    """거래내역 조회"""
    api = get_hana_api()
    data = request.get_json() or {}

    account_no = data.get("accountNo", "")
    start_date = data.get("startDate", "")
    end_date = data.get("endDate", "")

    if not account_no:
        return api_response(False, error="계좌번호가 필요합니다.", status=400)

    orders = api.get_orders(account_no, start_date, end_date)

    return api_response(True, {
        "orders": [
            {
                "orderId": o.order_id,
                "type": o.order_type,
                "currency": o.currency,
                "amount": o.amount,
                "rate": o.rate,
                "status": o.status,
                "orderedAt": o.ordered_at,
            }
            for o in orders
        ]
    })


def run_server(host: str = None, port: int = None):
    """서버 실행"""
    from waitress import serve

    host = host or SERVER_HOST
    port = port or SERVER_PORT

    logger.info(f"PC Bridge 서버 시작: http://{host}:{port}")
    serve(app, host=host, port=port, threads=4)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_server()
