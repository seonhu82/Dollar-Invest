"""
PC Bridge 설정
"""

# 서버 설정
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8585

# 브릿지 버전
VERSION = "1.0.0"

# 하나증권 설정
HANA_PROG_ID = "HFCommAgent.HFCommAgent.1"  # 하나증권 COM ProgID

# 로그 설정
LOG_FILE = "bridge.log"
LOG_LEVEL = "INFO"
